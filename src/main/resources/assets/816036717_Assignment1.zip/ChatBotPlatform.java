import java.util.ArrayList;

/**
 * 816036717
 * 
The ChatBotPlatform class manages one or more ChatBot objects within a bots collection.
 */
public class ChatBotPlatform
{
    // Attribute
    private ArrayList<ChatBot> bots;
    
    public ChatBotPlatform() { // Constructor
        bots = new ArrayList<>();
    }
    
    public boolean addChatBot(int LLMcode) { // Creates and adds a new ChatBot object to the bots collection based on the LLM code supplied. The method returns true if successful, false otherwise. It first checks whether the limit has been reached for the number of messages that can be sent by the platform. If not, then a new ChatBot object is created and added to the bots collection using the ArrayList method.
        if(!ChatBot.limitReached()) {
            bots.add(new ChatBot(LLMcode));
            
            return true;
        }
        
        return false;
    }
    
    public String getChatBotList() { // Returns a String containing formatted information about all of the chatbots managed by the ChatBotPlatform object together with summary usage statistics.
        String ChatBotList = "";
        
        for(int i=0; i<bots.size(); i++) {
            ChatBotList += "Bot Number: " + i + " " + bots.get(i).toString() + "\n";
        }
        
        ChatBotList += "Total Messages Used: " + ChatBot.getTotalNumResponsesGenerated() + "\nTotal Messages Remaining: " + ChatBot.getTotalNumMessagesRemaining();
        return ChatBotList;
    }
    
    public String interactWithBot(int botNumber, String message) { // Passes a message to a given chatbot and returns its response. The botNumber represents the index of a chatbot in the bots collection. If an incorrect botNumber is supplied, the method returns an informative message with indicating the wrong number
        if(botNumber < 0 || botNumber >= bots.size()) {
            return "Incorrect Bot Number (" + botNumber + ") Selected. Try again";
        }
        
        return bots.get(botNumber).prompt(message);
    }
       
    public int getNumBots() { // Accessor for number of bots
        return bots.size();
    }
}
