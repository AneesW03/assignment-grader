// 816030569
import java.util.ArrayList;

public class ChatBotPlatform {
    ArrayList<ChatBot> bots;
    
    //Constructor
    public ChatBotPlatform() {
        bots = new ArrayList<ChatBot>();
    }
    
    public int getSize() {
        return bots.size();
    }
     
    public boolean addChatBot(int LLMcode) {
        ChatBot bot = new ChatBot(LLMcode);
        if(!bot.limitReached()) {
            bots.add(bot);
            return true;
        }
        return false;
    }
    
    public String getChatBotList() {
        String heading = "----------------------\n Your ChatBots";
        String stats = "";
        for(ChatBot b : bots) {
            stats += "\nBot Number: " + bots.indexOf(b) + b.toString();
        }
        String closing = "\nTotal Messages Used: " + bots.get(0).getTotalNumResponsesGenerated() + "\nTotal Messages Remaining: " + bots.get(0).getTotalNumMessagesRemaining() + "\n----------------------";
        return heading + stats + closing;
    }
    
    public String interactWithBot(int botNumber, String message) {
        if(botNumber > bots.size() || botNumber < 0) {
            return "Incorrect Bot Number (" + botNumber + ") Selected. Try Again";
        }
        ChatBot B = bots.get(botNumber);
        return B.prompt(message);
    }
}