// 81030569
import java.util.Random;

public class ChatBotSimulation {
    public static void main(String[] args) {
        System.out.println("Hello World");
        ChatBotPlatform chatBotsList = new ChatBotPlatform();
        for(int i = 0; i <= 5; i++) { // to only initialize 0 to 5 as these are predefined in ChatBotGenerator class method
            chatBotsList.addChatBot(i);
        }
        System.out.println(chatBotsList.getChatBotList());
        
        Random R = new Random();
        for(int j = 0; j < 15; j++) {
            int randomNumber = R.nextInt(chatBotsList.getSize());
            System.out.println(chatBotsList.interactWithBot(randomNumber,"Hello"));
        }
        
        System.out.println(chatBotsList.getChatBotList());
    }
}