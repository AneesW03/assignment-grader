// 816030569

public class ChatBot {
    String chatBotName;
    int numResponsesGenerated = 0;
    static int messageLimit = 10;
    static int messageNumber = 0;
    
    //Constructors
    public ChatBot() {
        setChatBotName(ChatBotGenerator.generateChatBotLLM(0));
    }
    
    public ChatBot(int LLMCode) {
        setChatBotName(ChatBotGenerator.generateChatBotLLM(LLMCode));
    }
    
    //Accessors
    public String getChatBotName() { return chatBotName; }
    public int getNumResponsesGenerated() { return numResponsesGenerated; }
    public int getTotalNumResponsesGenerated() { return messageNumber; }
    public int getMessageLimit() { return messageLimit; }
    
    //Mutators
    public void setChatBotName(String name) { this.chatBotName = name; }
    public void setNumResponsesGenerated(int number) { this.numResponsesGenerated = number; }
    public void setMessageLimit(int limit) { this.messageLimit = limit; }
    public void setMessageNumber(int number) { this.messageNumber = number; }
    
    //Methods
    public int getTotalNumMessagesRemaining() { 
        return getMessageLimit() - getTotalNumResponsesGenerated();
    }
    
    public boolean limitReached() {
        if(getTotalNumMessagesRemaining() <= 0) {
            return true;
        }
        return false;
    }
    
    private String generateResponse() {
        setNumResponsesGenerated(getNumResponsesGenerated() + 1);
        setMessageNumber(getTotalNumResponsesGenerated() + 1);
        String response = "Message# " + getTotalNumResponsesGenerated() + ")\tResponse from " + getChatBotName() + "\t>> generatedTextHere";
        return response;
    }
    
    public String prompt(String requestMessage) {
        if(limitReached()) {
            return "Daily Limit Reached. Wait 24 hours to resume chatbot usage";
        }
        return generateResponse();
    }
    
    public String toString() {
        return "\tChatBot Name: " + getChatBotName() + "\tNumber Messages Used: " + getNumResponsesGenerated();
    }
}