// 816030569

public class ChatBotGenerator {
    public static String generateChatBotLLM(int LLMCodeNumber) {
        String botName;
        if(LLMCodeNumber == 1) {
            botName = "LLaMa";
        }
        else if(LLMCodeNumber == 2) {
            botName = "Mistral7B";
        }
        else if(LLMCodeNumber == 3) {
            botName = "Bard";
        }
        else if(LLMCodeNumber == 4) {
            botName = "Claude";
        }
        else if(LLMCodeNumber == 5) {
            botName = "Solar";
        }
        else {
            botName = "ChatGPT-3.5";
        }
        return botName;
    }
}