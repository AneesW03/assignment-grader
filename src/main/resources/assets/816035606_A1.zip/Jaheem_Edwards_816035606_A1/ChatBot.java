//Student ID - 816035606

public class ChatBot
{
    private String chatBotName;
    private int numResponsesGenerated;
    private int messageLimit;
    private int messageNumber;
    
    //Constructors
    
    public ChatBot()
    {
        ChatBotGenerator bot = new ChatBotGenerator();
        
        setChatBotName(bot.generateChatBotLLM(0));
        setNumResponsesGenerated(0);
        setMessageLimit(10);
        setMessageNumber(0);
    }
    
    public ChatBot(int LLMCode) //Overloaded constructor
    {
        ChatBotGenerator bot = new ChatBotGenerator();
        
        setChatBotName(bot.generateChatBotLLM(LLMCode));
        setNumResponsesGenerated(0);
        setMessageLimit(10);
        setMessageNumber(0);
    }

    //Accessors
    public String getChatBotName()              { return chatBotName; }
    public int getNumResponsesGenerated()       { return numResponsesGenerated; }
    public int getMessageLimit()                { return messageLimit; }
    public int getTotalNumResponsesGenerated()  { return messageNumber; }
    
    //Mutators
    public void setChatBotName(String chatBotName)                  { this.chatBotName = chatBotName; }
    public void setNumResponsesGenerated(int numResponsesGenerated) { this.numResponsesGenerated = numResponsesGenerated; }
    public void setMessageLimit(int messageLimit)                   { this.messageLimit = messageLimit; }
    public void setMessageNumber(int messageNumber)                 { this.messageNumber = messageNumber; }
    
    //Methods
    public int getTotalNumMessagesRemaining() {
        return getMessageLimit() - getTotalNumResponsesGenerated();
    }
    
    public boolean limitReached() {
        return getTotalNumResponsesGenerated() >= getMessageLimit();
    }
    
    private String generateResponse() {
        int message = this.getNumResponsesGenerated() + 1;
        int totalMessages = this.getTotalNumResponsesGenerated() + 1;
        
        this.setNumResponsesGenerated(message);
        this.setMessageNumber(totalMessages);
        
        return "(Message# " + getTotalNumResponsesGenerated() +
                ") Response from " + getChatBotName() 
                 + "\t>>generatedTextHere";
    }
    
    public String prompt(String requestMessage) {
        
        if(!limitReached()) {
            return generateResponse();
        }
        return "Daily Limit Reached. Wait 24 hours to resume chatbot usage";
    }
    
    public String toString() {
        return "ChatBot Name: " + getChatBotName() + "\tNumber Messages Used: " + getNumResponsesGenerated();
    }
}
