//Student ID - 816035606

import java.util.Random;

public class ChatBotSimulation
{
    public static void main(String[] args) {
        
        int numberOfBots = 6;
        int randomNumRange = numberOfBots + 2;
        int randomBot;
        int i;
        int numberOfInteractions = 15;
        String message = "Hello bot";
        String output;
        
        ChatBotPlatform chats = new ChatBotPlatform();
        Random random = new Random();
        
        System.out.println("Hello World!");
        
        for(i = 0; i <= numberOfBots; i++) {
            chats.addChatBot(i);
        }
        
        System.out.println(chats.getChatBotList());
        
        for(i = 0; i < numberOfInteractions; i++) {
            randomBot = random.nextInt(randomNumRange);
            output = chats.interactWithBot(randomBot, message);
            System.out.println(output);
        }
        
        System.out.println(chats.getChatBotList());
    }
}
