//Student ID - 816035606

import java.util.ArrayList;

public class ChatBotPlatform
{
    private ArrayList<ChatBot> bots;

    //Constructors
    public ChatBotPlatform()
    {
        bots = new ArrayList<ChatBot>();
    }

    //Accessors
    public ArrayList<ChatBot> getBots() { return bots; }
    
    //Mutators
    public void setBots(ArrayList<ChatBot> bots) { this.bots = bots; }
    
    //Methods
    public boolean addChatBot(int LLMCode) {
        
        ChatBot bot = new ChatBot(LLMCode);
        
        if(bot.limitReached()) {
            return false;
        } 
        
        bots.add(bot);
        
        return true;
    }
    
    public String getChatBotList() {
        
        String message = "-----------------\n";
        message += " Your ChatBots\n";
        
        for(int i = 0; i < bots.size(); i++) {
            message += "Bot Number: " + i + " " + bots.get(i).toString() + "\n";
        }
        
        message += "Total Messages Used: " + bots.get(0).getTotalNumResponsesGenerated() + "\n";
        message += "Total Messages Remaining: " + bots.get(0).getTotalNumMessagesRemaining() + "\n";
        message += "-----------------";
        
        return message;
    }
    
    public String interactWithBot(int botNumber, String message) {
        
        if(botNumber >= bots.size()) {
            return "Incorrect Bot Number (" + botNumber + ") Selected. Try again";
        }
        
        String output = bots.get(botNumber).prompt(message);
        String check = "Daily Limit Reached. Wait 24 hours to resume chatbot usage";
        
        if(!check.equals(output)) {
            for(int i = 0; i < bots.size(); i++) { 
                if(botNumber != i) {
                    bots.get(i).setMessageNumber(bots.get(i).getTotalNumResponsesGenerated() + 1);
                } 
            }
        }
        return output;
    }
}
