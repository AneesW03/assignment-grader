
/**
 * 816036717
 * 
The ChatBotGenerator class models the generation of various LLMs.
 */
public class ChatBotGenerator
{
    public static String generateChatBotLLM(int LLMCodeNumber) { // A class method that returns the name of an LLM based on a supplied integer code.
        if(LLMCodeNumber == 1) {
            return "LLaMa";
        } else if (LLMCodeNumber == 2) {
            return "Mistral7B";
        } else if (LLMCodeNumber == 3) {
            return "Bard";
        } else if (LLMCodeNumber == 4) {
            return "Claude";
        } else if (LLMCodeNumber == 5) {
            return "Solar";
        } else {
            return "ChatGPT-3.5";
        }
    }
}
