import java.util.Random;
/**
816036717
 */
public class ChatBotSimulation
{
    public static void main(String[] args) {
        System.out.println("Hello World!");
        
        ChatBotPlatform chatBotPlatform = new ChatBotPlatform();
        
        for(int i=0; i<=5; i++) { // Adds ChatBot objects to the ChatBotPlatform
            chatBotPlatform.addChatBot(i);
        }
        
        System.out.println("----------------------");
        System.out.println(" Your ChatBots");
        System.out.println(chatBotPlatform.getChatBotList()); // Prints the list of all ChatBots managed by the ChatBotPlatform with their summary statistics
        System.out.println("----------------------");
        
        Random random = new Random();
        for(int i=0; i<15; i++) { // . Interacts up to 15 times with random ChatBots by sending messages, printing out their responses to the screen
           int botNum = random.nextInt(chatBotPlatform.getNumBots() + 1); // 1 is added to demonstrate how the program handles an incorrect bot number.
           
           System.out.println(chatBotPlatform.interactWithBot(botNum, "Haiii :3"));
        }
        
        System.out.println("----------------------");
        System.out.println(" Your ChatBots");
        System.out.println(chatBotPlatform.getChatBotList()); // Prints out a final list of all ChatBots managed by the ChatBotPlatform with their summary statistics
        System.out.println("----------------------");
    }
}
